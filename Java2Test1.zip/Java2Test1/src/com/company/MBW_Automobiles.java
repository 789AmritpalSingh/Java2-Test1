package com.company;
import java.util.ArrayList;
import java.util.List;

/**
 * This superclass Vehicle has all the information like registration number,vehicle price , model , year of purchase
 * depreciation
 *
 * @author Amritpal Singh
 *
 * @version 2.0
 */
class Vehicle{
    /**
     * attributes assigned to this class are registrationNum for the registration number of the vehicle, price for vehicle
     * price, model of the vehicle, yearOfPurchase in which year it was purchased,currentYear for the current year,
     * depreciation for the depreciation value of the vehicle
     */
    private String registrationNum;
    static protected double price;
    private String model;
    static protected double yearOfPurchase;
    static protected double currentYear;
    static protected  double depreciation;

    /**
     * There is a constructor created for the class Vehicle which takes attributes of the class as parameter
     * @param registrationNum stores registration number of the vehicle
     * @param price stores price of the vehicle
     * @param model takes model of the vehicle as input
     * @param yearOfPurchase stores year of purchase like in which car was purchased
     * @param currentYear takes current year as parameter
     * @param depreciation stores the depreciation value of the vehicle
     */

    public Vehicle(String registrationNum,double price,String model,double yearOfPurchase,double currentYear,double depreciation){
        this.registrationNum = registrationNum;
        Vehicle.price = price;
        this.model = model;
        Vehicle.yearOfPurchase = yearOfPurchase;
        Vehicle.currentYear = currentYear;
        Vehicle.depreciation = depreciation;
    }

    /**
     * getter method for the registrationNum variable
     * @return returns the value of the registration number
     */

    public String getRegistrationNum() {
        return registrationNum;
    }

    /**
     * setter method for the registration number
     * @param registrationNum sets the value of the registration number by taking the input
     */

    public void setRegistrationNum(String registrationNum) {
        this.registrationNum = registrationNum;
    }

    /**
     * getter method for the model of the vehicle
     * @return returns the model of the vehicle
     */

    public String getModel() {
        return model;
    }

    /**
     * setter method for the model
     * @param model  sets the model of the vehicle
     */

    public void setModel(String model) {
        this.model = model;
    }
}

/**
 * Here is subclass Car inheriting from the parent class Vehicle like all the attributes, methods are inherited of vehicle class
 */

class Car extends Vehicle{
    /**
     * took numOfPassengers as a variable which stores how many passengers can sit in the car
     */
    private int numOfPassengers;

    /**
     * getter method for the numOfPassengers
     * @return returns numOfPassengers
     */

    public int getNumOfPassengers() {
        return numOfPassengers;
    }

    /**
     * setter method for numOfPassengers
     * @param numOfPassengers sets the value for the numOfPassengers
     */

    public void setNumOfPassengers(int numOfPassengers) {
        this.numOfPassengers = numOfPassengers;
    }

    /**
     * Constructor for class Car has been created which takes registrationNum,price,model,yearOfPurchase,currentYear,
     * depreciation inherited from vehicle class and numOfPassengers also as a parameter
     * @param registrationNum stores registration number of car
     * @param price stores price of the car
     * @param model stores model of the car
     * @param yearOfPurchase year of purchase is stored
     * @param currentYear current year is stored
     * @param depreciation stores depreciation value for the car
     * @param numOfPassengers number of passengers who can sit in the car is stored
     */

    public Car(String registrationNum, double price, String model, double yearOfPurchase, double currentYear,
               double depreciation,int numOfPassengers) {
        super(registrationNum, price, model, yearOfPurchase, currentYear, depreciation);
        this.numOfPassengers = numOfPassengers;
    }

    /**
     * Method currentCarPrice is created for getting current price of the car
     * @param car takes car object as a parameter
     * @return returns the current price of the car
     */

    static double currentCarPrice(Car car){
        return price-(depreciation)/100*(currentYear-yearOfPurchase)*price;
    }

}

/**
 * class PickUpTruck is created which inherits vehicle class
 */
class PickUpTruck extends Vehicle{
    /**
     * Variable loadCapacity is created which tells the capacity of the truck up to which it can load
     */
    private String loadCapacity;

    /**
     * getter method for the load capacity
     * @return returns the load capacity
     */

    public String getLoadCapacity() {
        return loadCapacity;
    }

    /**
     *  setter method for the load capacity
     * @param loadCapacity sets the value of the load capacity
     */

    public void setLoadCapacity(String loadCapacity) {
        this.loadCapacity = loadCapacity;
    }

    /**
     * Constructor created for the class PickUpTruck which stores inherited attributes of the class vehicle and
     * also has its own attribute load capacity
     * @param registrationNum stores registration number of the truck
     * @param price stores price of the truck
     * @param model stores model of the truck
     * @param yearOfPurchase stores year of purchase of truck
     * @param currentYear current year is stored
     * @param depreciation depreciation value is stored
     * @param loadCapacity load capacity of truck is stored
     */

    public PickUpTruck(String registrationNum, double price, String model, double yearOfPurchase, double currentYear,
                       double depreciation, String loadCapacity) {
        super(registrationNum, price, model, yearOfPurchase, currentYear, depreciation);
        this.loadCapacity = loadCapacity;
    }

    /**
     * Method currentPickUpTruckPrice is created for the current price of the truck
     * @param truck stores object truck as parameter
     * @return returns current price of the truck
     */

    static double currentPickUpTruckPrice(PickUpTruck truck){
        return price-(depreciation)/100*(currentYear-yearOfPurchase)*price;
    }

}

/**
 * Class Motorcycle is created which inherits parents class Vehicle having all the attributes for the motorcycle
 */

class Motorcycle extends Vehicle{
    /**
     * topSpeed variable is created for storing the top speed of the motorcycle
     */
    private String topSpeed; // taken String because the km/hr will be written with value.

    /**
     * getter method for the top speed of the motorcycle
     * @return returns top speed of the motorcycle
     */

    public String getTopSpeed() {
        return topSpeed;
    }

    /**
     * setter method for topSpeed
     * @param topSpeed sets the value for the topSpeed of the motorcycle
     */

    public void setTopSpeed(String topSpeed) {
        this.topSpeed = topSpeed;
    }

    /**
     * Constructor for the class Motorcycle is created which takes attributes of the vehicle class and also its own
     * attribute topSpeed as a parameter
     * @param registrationNum stores registration number of the motorcycle
     * @param price stores price of the motorcycle
     * @param model stores model of the motorcycle
     * @param yearOfPurchase stores year of purchase for the motorcycle
     * @param currentYear stores current year
     * @param depreciation stores depreciation value for the motorcycle
     * @param topSpeed stores top speed of the motorcycle
     */
    public Motorcycle(String registrationNum, double price, String model, double yearOfPurchase, double currentYear,
                      double depreciation,String topSpeed) {
        super(registrationNum, price, model, yearOfPurchase, currentYear, depreciation);
        this.topSpeed = topSpeed;
    }

    /**
     * Created a method currentBikePrice for the getting current price for the motorcycle
     * @param bike  takes bike object as a parameter
     * @return returns current price of the motorcycle
     */

    static double currentBikePrice(Motorcycle bike){
        return price-(depreciation)/100*(currentYear-yearOfPurchase)*price;
    }

}

/**
 * Class showroom for the vehicles in the showroom is created
 */
class Showroom{
    /**
     * attributes name and list of inventory is created to store name and list of the vehicles
     */
    private String name;
    List<String>Inventory = new ArrayList<String>(100);


    /**
     * getter method for getting name of the vehicle
     * @return return name of the vehicle
     */
    public String getName() {
        return name;
    }

    /**
     * setter method for setting name of the vehicle
     * @param name sets the name of the vehicle
     */

    public void setName(String name) {
        this.name = name;
    }

    /**
     * getter method for getting list of inventory vehicles
     * @return returns inventory items
     */

    public List<String> getInventory() {
        return Inventory;
    }

    /**
     * setter method for adding value to list of the inventory
     * @param inventory sets the value to the list of inventory
     */

    public void setInventory(List<String> inventory) {
        Inventory = inventory;
    }

    /**
     *  Constructor for the class Showroom
     * @param name takes parameter name for storing name of the vehicle
     * @param inventory stores list of vehicles in inventory
     */
    public Showroom(String name, List<String> inventory) {
        this.name = name;
        Inventory = inventory;
    }



    /**
     * Method addToInventory is created for adding the vehicles to the list
     * @param name takes name of the vehicle as parameter
     * @return returns message according to the size of the inventory list
     */

    public String addToInventory(String name){
        if(Inventory.size()>100){
            return "Inventory Overflow";
        }
        else{
            if(Inventory.size()==98){
                return "Low Inventory";
            }
            else{
                Inventory.add(name);
                return "Inventory updated";
            }
        }
    }

    /**
     * Method walkThrough is created for displaying vehicles in the inventory
     */
    public void walkThrough(){
        for(String vehicles:Inventory){
            System.out.println(vehicles);
        }
    }
}

public class MBW_Automobiles {
    public static void main(String[] args) {
        Car c = new Car("A42H33",5000,"Honda Civic",2017,2022,15,4);
        Showroom s = new Showroom("Honda Civic",{"Honda Civic, Hayabusa"});
        s.addToInventory("Honda Civic");
        s.walkThrough();
    }
}
