package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MotorcycleTest {

    @Test
    void currentBikePrice() {
        Motorcycle m = new Motorcycle("PBO2322",3000,"Hayabusa",2022,20,20,"300mph");
        m.setTopSpeed("250mph");
        assertEquals("250mph",m.getTopSpeed());
    }
}