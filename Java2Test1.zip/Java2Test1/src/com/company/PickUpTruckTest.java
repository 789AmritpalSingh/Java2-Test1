package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PickUpTruckTest {

    @Test
    void currentPickUpTruckPrice() {
        PickUpTruck t = new PickUpTruck("AB3835",4000,"Ford",2018,2022,
                9,"5000kg");
        t.setLoadCapacity("6000kg");
        assertEquals(6000,t.getLoadCapacity());
    }
}