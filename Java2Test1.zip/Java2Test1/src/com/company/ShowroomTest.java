package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ShowroomTest {

    @Test
    void addToInventory() {
        Showroom s = new Showroom("Honda Civic",{"Honda Civic , Mustang"});
        s.setName("Dodge");
        assertEquals("Dodge",s.getName());
    }
}